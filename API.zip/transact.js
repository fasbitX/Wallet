let debc = require('./lib/debc');
debc.subscribe(console.log)